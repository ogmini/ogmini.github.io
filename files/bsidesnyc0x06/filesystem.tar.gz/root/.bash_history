dietpi-config
exit
shutdown -h now
sudo apt update
sode apt upgrade
sudo apt upgrade
shutdown -r now
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
exit
