Samba client: Can be installed and setup by DietPi-Drive_Manager.
Simply run "dietpi-drive_manager" and select "Add network drive".
